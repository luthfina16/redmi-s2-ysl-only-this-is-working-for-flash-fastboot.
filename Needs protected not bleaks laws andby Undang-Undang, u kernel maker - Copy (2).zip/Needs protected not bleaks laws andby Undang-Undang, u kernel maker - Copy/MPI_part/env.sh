module add languages/intel/2018-u3
